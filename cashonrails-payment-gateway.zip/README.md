# cashonrails Plugin for UCRM
This plugin integrates cashonrails payment gateway with UCRM, allowing your customers to make payments through the cashonrails platform.

## Installation
1. Download the plugin ZIP file
2. Navigate to your UCRM's System > Plugins page
3. Upload the plugin ZIP file
4. Configure the plugin with your cashonrails API keys

## Configuration
After installation, you need to configure the plugin with the following settings:

- **cashonrails Secret Key**: Your cashonrails secret key (found in your cashonrails dashboard)
- **cashonrails Public Key**: Your cashonrails public key (found in your cashonrails dashboard)
- **Webhook URL** (optional): A URL where cashonrails will send payment notifications (configure this in your cashonrails dashboard)
- **Currency Code**: The currency code to use for payments (e.g., NGN, USD, GHS)

## How It Works
1. Customers are presented with a payment form showing their unpaid invoices
2. They select the invoice they want to pay and enter the payment amount
3. They're redirected to cashonrails to complete the payment
4. After successful payment, they're redirected back to UCRM
5. The payment is automatically added to UCRM and applied to the selected invoice

## Features
- Seamless integration with UCRM
- Secure payment processing through cashonrails
- Automatic application of payments to invoices
- Detailed payment records with transaction references

## Troubleshooting
If you encounter any issues:

1. Check that your cashonrails API keys are correctly configured
2. Ensure your UCRM server can make outbound HTTP requests to the cashonrails API
3. Verify that the plugin has the necessary permissions in UCRM
4. Check the UCRM logs for any error messages

## Support
For support, please contact the plugin developer or submit an issue on the GitHub repository.
